package com.exercicioum.exercicioum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioumApplicationTests {

	@Test
	void contextLoads() {
	}

}
