package com.exercicioum.exercicioum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioumApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioumApplication.class, args);
	}

}
