package com.minhalojadegames.minhalojadegames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhalojadegamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhalojadegamesApplication.class, args);
	}

}
